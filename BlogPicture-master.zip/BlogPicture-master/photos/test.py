import tool
import os
#tool.list_img_file(os.getcwd())
tool.handle_photo()
